//
//  A Demo for iOS Development Tips Weekly
//  by Steven Lipton (C)2018, All rights reserved
//  For videos go to http://bit.ly/TipsLinkedInLearning
//  For code go to http://bit.ly/AppPieGithub
//

//:#Property Wrappers
//: A demo to demonstrate Swift Property wrappers
import UIKit

struct PizzaItem{
    var topping1:String = "Cheese"
    var topping2:String = "Gorgonzola"
    var size:Int = 10
}


var a = PizzaItem()
a.topping1
a.topping2
a.topping2 = "cheese"
a.topping2












